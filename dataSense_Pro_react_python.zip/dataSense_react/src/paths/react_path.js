export const loginRoute = "/login";

export const registerRoute = "/register";
